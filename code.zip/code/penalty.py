# Author: Mathieu Blondel
# License: BSD

import numpy as np
from numba import jit
from scipy.linalg import svd, norm


class L1Penalty(object):

    def projection(self, coef, alpha, L):
        return np.sign(coef) * np.maximum(np.abs(coef) - alpha / L, 0)

    def regularization(self, coef):
        return np.sum(np.abs(coef))


class L1L2Penalty(object):

    def projection(self, coef, alpha, L):
        l2norms = np.sqrt(np.sum(coef ** 2, axis=0))
        scales = np.maximum(1.0 - alpha / (L * l2norms), 0)
        coef *= scales
        return coef

    def regularization(self, coef):
        return np.sum(np.sqrt(np.sum(coef ** 2, axis=0)))

class L1L2_L1Penalty(object):

    def __init__(self, rho=None):
        self.rho = rho

    def projection(self, coef, alpha, L):
        # component-wise soft-thresholding
        coef = np.sign(coef) * np.maximum(np.abs(coef) - (alpha * (1.0 - self.rho)) / L, 0)
        # column-wise (group) soft-thresholding
        l2norms = np.sqrt(np.sum(coef ** 2, axis=0))
        # scales = np.maximum(1.0 - (alpha * self.rho) / (L * l2norms), 0)
        # coef *= scales
        scales = np.zeros_like(l2norms)
        scales[np.nonzero(l2norms)] = np.maximum(
            1.0 - (alpha * self.rho) / (L * l2norms[np.nonzero(l2norms)]),
            0
        )
        coef *= scales
        return coef

    def regularization(self, coef):
        return self.rho * np.sum(np.sqrt(np.sum(coef ** 2, axis=0))) + (1 - self.rho) * np.sum(np.abs(coef))

# Non-convex regularizers and associated prox
@jit
def soft_thresh(x, gam):
    return np.sign(x) * np.maximum(np.abs(x) - gam, 0)

@jit
def prox_l2_norm(x, norm_x, gam):
    res = x * (1 - (gam / np.maximum(norm_x, gam)) )
    return res

@jit
def prox_mcpl1_col(Xi, alpha, theta):
    # Xi = Xi.ravel()
    res = np.empty_like(Xi)
    for j in range(Xi.size):
        norm_Xi_expt_j = np.sum(np.absolute(np.delete(Xi, j)))
        if np.abs(Xi[j]) < alpha*theta - norm_Xi_expt_j:
            res[j] = soft_thresh(Xi[j], gam=alpha - norm_Xi_expt_j/theta)
            res[j] *= theta / (theta - 1)
        else:
            res[j] = Xi[j]
    return res

@jit
def prox_scadl2_col(Xi, alpha, theta):
    norm_Xi = np.sqrt(np.sum(Xi**2))

    if norm_Xi <= 2*alpha:
        res = prox_l2_norm(Xi, norm_x=norm_Xi, gam=alpha)
    elif 2*alpha < norm_Xi <= alpha*theta:
        res = prox_l2_norm(Xi, norm_x=norm_Xi, gam=theta * alpha / (theta - 1))
        res *= (theta - 1) / (theta - 2)
    else:
        res = Xi    
    return res

@jit
def prox_scadl1_col(Xi, alpha, theta):
    Xi = Xi.ravel()
    res = np.empty_like(Xi)
    norm_Xi_ecpt_j = np.sum(np.abs(Xi))
    for j in range(Xi.size):
        # norm_Xi = norm(Xi, ord=1)
        # norm_Xi_ecpt_j = np.sum(np.abs(np.delete(Xi, j)))
        if (np.abs(Xi[j])  + norm_Xi_ecpt_j <= 2*alpha):
            res[j] = soft_thresh(Xi[j], gam = alpha)

        elif (2*alpha < np.abs(Xi[j]) + norm_Xi_ecpt_j <= alpha*theta):
            res[j] = soft_thresh(Xi[j], gam = (alpha*theta - norm_Xi_ecpt_j) / (theta - 1))
            res[j] *= (theta - 1) / (theta - 2)

        else:
            res[j] = Xi[j]
    return res

def _scad(x, gam, theta):
    if (np.abs(x) <= gam):
        res = gam * np.abs(x)
    elif (gam < np.abs(x) <= gam * theta):
        res = (2*gam*theta * np.abs(x) - x**2 - gam**2) / (2 * (theta - 1))
    else:
        res = gam**2 * (theta+1) / 2
    return(res)
scad = np.vectorize(_scad, excluded = ['gam', 'theta'])

def _mcp(x, gam, theta):
    x_abs = np.abs(x)
    if (x_abs <= theta): # elementwise comparison (abs(x_1),...abs(x_j),...)
        res = x_abs
        res -= np.square(x)/(2*theta)
    else:
        res = theta / 2
    return gam * res
mcp = np.vectorize(_mcp, excluded = ['gam', 'theta'])

def _prox_mcp(x, gam, theta):
    if np.abs(x) <= gam*theta:
        res = soft_thresh(x, gam=gam)
        res *= theta / (theta - 1)
    else:
        res = x
    return res
prox_mcp = np.vectorize(_prox_mcp, excluded = ['gam', 'theta'])

def _prox_scad(x, gam, theta):
    if (np.abs(x) <= 2*gam):
        res = soft_thresh(x, gam=gam)
    elif (2*gam < np.abs(x) <= gam*theta):
        res = (theta - 1) / (theta - 2) * soft_thresh(x, gam=theta * gam / (theta - 1))
    else:
        res = x
    return res
prox_scad = np.vectorize(_prox_scad, excluded = ['gam', 'theta'])

class SCADPenalty(object):

    def __init__(self, theta=None):
        self.theta = theta

    def projection(self, coef, alpha, L):
        return prox_scad(coef, gam=alpha / L, theta=self.theta)

    def regularization(self, coef):
        return scad(coef, gam=1.0, theta=self.theta).sum()

class SCADL2Penalty(object):

    def __init__(self, theta=None):
        self.theta = theta

    def projection(self, coef, alpha, L):
        theta = self.theta
        return np.apply_along_axis(
            prox_scadl2_col,
            axis=0,
            arr = coef, 
            alpha=alpha / L, theta=theta)
        
    def regularization(self, coef):
        theta = self.theta
        norm_xi = np.sqrt(np.sum(coef**2, axis=0))
        return scad(norm_xi, gam=1.0, theta=theta).sum()

class SCADL1Penalty(object):

    def __init__(self, theta=None):
        self.theta = theta

    def projection(self, coef, alpha, L):
        theta = self.theta
        return np.apply_along_axis(
            prox_scadl1_col,
            axis=0, # threshold one feature (column) across all tasks (rows)
            arr = coef, 
            alpha=alpha / L, theta=theta)
        
    def regularization(self, coef):
        theta = self.theta
        norm_xi = np.sum(np.abs(coef), axis=0)
        return scad(norm_xi, gam=1.0, theta=theta).sum()

class MCPL1Penalty(object):

    def __init__(self, theta=None):
        self.theta = theta

    def projection(self, coef, alpha, L):
        theta = self.theta
        return np.apply_along_axis(
            prox_mcpl1_col,
            axis=0, # threshold one feature (column) across all tasks (rows)
            arr = coef, 
            alpha=alpha / L, theta=theta)
        
    def regularization(self, coef):
        theta = self.theta
        norm_xi = np.sum(np.abs(coef), axis=0)
        return mcp(norm_xi, gam=1.0, theta=theta).sum()

- Main libraries used and to be installed
(see .yaml for details on the version or top of the notebooks):
- scikit-learn
- numpy
- scipy
- pysindy (use the one we provide in zip, as we've "manually" modified some of its features)
- lightning
- numba

==========
Play with the notebooks. The settings of the paper experiments are at the end of the notebooks.

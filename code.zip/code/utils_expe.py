"""utility functions for the numerical experiments"""

import numpy as np
import pandas as pd

def misidentif_err(coef_hat, true_coef):
    """returns rate of misidentified candidate functions"""
    n_misident_nonzero_terms = np.nonzero(coef_hat[np.nonzero(true_coef == 0.0)])[0].size
    return n_misident_nonzero_terms / np.argwhere(true_coef == 0.0).shape[0]

def bias_recov_support(coef_hat, true_coef):
    """returns the relative bias in l2 norm"""
    error = np.linalg.norm(
        coef_hat[np.nonzero(true_coef)] - true_coef[np.nonzero(true_coef)]
    )
    return error / np.linalg.norm(true_coef[np.nonzero(true_coef)])

def sode_recov_sim_error(sode_hat, true_sim, x0, t):
    hat_sim = sode_hat
    # relative squared error for each t
    err = np.square(hat_sim - true_sim).sum(axis=1).sum() / np.square(true_sim).sum(axis=1).sum()
    return err

def log_snr(sode_params):
    """log-ratio (decibels) of weighted variance of the true signal divided by noise variance"""
    var_state_variables = np.var(sode_params['true_sol'], axis=0)
    weights = var_state_variables / var_state_variables.sum()
    snr = np.average(var_state_variables, weights=weights, axis=None)
    snr /= sode_params['noise_level']
    return np.log10(snr) * 10

def var_noise_from_logsnr(sode_params, log_snr):
    """Noise variance corresponding to a given log_snr"""
    var_state_variables = np.var(sode_params['true_sol'], axis=0)
    weights = var_state_variables / var_state_variables.sum()
    var_weighted = np.average(var_state_variables, weights=weights, axis=None)
    var_noise = var_weighted * 10**(-log_snr / 10)
    return var_noise

def read_bias_results(trial_no, sode_name, noise_name, logsnr):
    return pd.read_pickle(f'./{sode_name}/{trial_no}_bias_noise-{noise_name}-logsnr{int(logsnr)}.pkl')

def read_supp_results(trial_no, sode_name, noise_name, logsnr):
    return pd.read_pickle(f'./{sode_name}/{trial_no}_supp_noise-{noise_name}-logsnr{int(logsnr)}.pkl')

def read_sim_sode_results(trial_no, sode_name, noise_name, logsnr):
    return pd.read_pickle(f'./{sode_name}/{trial_no}_sim_noise-{noise_name}-logsnr{int(logsnr)}.pkl')
    
# synthetic datasets settings
doc_params = {
    'name': 'doc',
    'dt': 1e-3,
    't_train_span': (0.0, 25.0),
    'noise_level': None, # placeholder
    'noise_type': 'gaussian', # 'gaussian', 'student' # placeholder
    'x0': (0.0, 2.0),
    'integrator_method': 'LSODA',
    'integrator_kwargs': {'rtol': 1e-8, 'atol': 1e-8},
}

lotka_params = {
    'name': 'lotka',
    'dt': 1e-3,
    't_train_span': (0.0, 4.5),
    'noise_level': None, # placeholder
    'noise_type': 'gaussian', # 'gaussian', 'student' # placeholder
    'x0': (10.0, 5),
    'integrator_method': 'LSODA',
    'integrator_kwargs': {'rtol': 1e-8, 'atol': 1e-8},
}

lorenz_params = {
    'name': 'lorenz',
    'dt': 1e-3,
    't_train_span': (0.0, 10.0),
    'noise_level': None, # placeholder
    'noise_type': 'gaussian', # 'gaussian', 'student' # placeholder
    'x0': (-5.0, 1.0, 20.0),
    'integrator_method': 'LSODA',
    'integrator_kwargs': {'rtol': 1e-8, 'atol': 1e-8},
}

# mu, nu, s = 0.01, 0.01, 1.0
mhd_params = {
    'name': 'mhd',
    'dt': 1e-3,
    't_train_span': (0.0, 40.0),
    'noise_level': None, # placeholder
    'noise_type': 'gaussian', # 'gaussian', 'student' # placeholder
    'x0': (-0.2, -0.4, -0.25, 0.10, 0.30, 0.10),
    'integrator_method': 'LSODA',
    'integrator_kwargs': {'rtol': 1e-4, 'atol': 1e-4},
}
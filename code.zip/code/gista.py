import numpy as np

from sklearn.utils.extmath import safe_sparse_dot
from sklearn.base import MultiOutputMixin
from sklearn.linear_model._base import _preprocess_data
from six.moves import xrange

from lightning.impl.base import BaseClassifier, BaseRegressor

from lightning.impl.dataset_fast import get_dataset

from lightning.impl.loss_fast import Squared
from lightning.impl.loss_fast import SquaredHinge
from lightning.impl.loss_fast import MulticlassSquaredHinge
from lightning.impl.loss_fast import MulticlassLog

from penalty import L1Penalty
from penalty import L1L2Penalty
from penalty import SCADL1Penalty, SCADPenalty, SCADL2Penalty, MCPL1Penalty
from penalty import L1L2_L1Penalty


class _BaseFista(object):

    def _get_penalty(self):
        if hasattr(self.penalty, 'projection'):
            return self.penalty

        penalties = {
            "l1": L1Penalty(),
            "l1/l2": L1L2Penalty(),
            "scad": SCADPenalty(theta=self.theta),
            "scadL1": SCADL1Penalty(theta=self.theta),
            "scadL2": SCADL2Penalty(theta=self.theta),
            "mcpL1": MCPL1Penalty(theta=self.theta),
            "l1/l2-l1": L1L2_L1Penalty(rho=self.theta)
        }

        self.alpha *= self.alpha_ratio
        self.beta *= (1 - self.alpha_ratio)
        return penalties[self.penalty]

    def _get_objective(self, df, y, loss):
        return self.C * loss.objective(df, y)

    def _get_regularized_objective(self, df, y, loss, penalty, coef):
        obj = self._get_objective(df, y, loss)
        obj += self.alpha * penalty.regularization(coef)
        return obj

    def _get_quad_approx(self, coefa, coefb, objb, gradb, L, penalty):
        approx = objb
        diff = coefa - coefb
        approx += np.sum(diff * gradb)
        approx += L / 2 * np.sum(diff ** 2)
        approx += self.alpha * penalty.regularization(coefa)
        return approx

    def _fit(self, X, y, n_vectors):
        n_samples, n_features = X.shape
        loss = self._get_loss()
        penalty = self._get_penalty()
        ds = get_dataset(X)

        df = np.zeros((n_samples, n_vectors), dtype=np.float64)
        coef = np.zeros((n_vectors, n_features), dtype=np.float64)
        coefx = coef
        G = np.zeros((n_vectors, n_features), dtype=np.float64)

        obj = self._get_regularized_objective(df, y, loss, penalty, coef)

        if self.max_steps == 0:
            # No line search, need to use constant step size.
            L = self.C * loss.lipschitz_constant(ds, n_vectors)
        else:
            # Do not bother to compute the Lipschitz constant (expensive).
            L = 1.0

        t = 1.0
        for it in xrange(self.max_iter):
            if self.verbose >= 1:
                print("Iter", it + 1, obj)

            # Save current values
            t_old = t
            coefx_old = coefx

            # Gradient
            G.fill(0.0)
            loss.gradient(df, ds, y, G)
            G *= self.C

            # Line search
            if self.max_steps > 0:
                objb = self._get_objective(df, y, loss)

            for tt in xrange(self.max_steps):
                # Solve
                coefx = coef - G / L
                coefx = penalty.projection(coefx, self.alpha, L)
                coefx /= 1 + self.beta

                dfx = safe_sparse_dot(X, coefx.T)
                obj = self._get_regularized_objective(dfx, y, loss, penalty,
                                                      coefx)
                approx = self._get_quad_approx(coefx, coef, objb, G, L, penalty)

                accepted = obj <= approx

                # Sufficient decrease condition
                if accepted:
                    if self.verbose >= 2:
                        print("Accepted at", tt + 1)
                    break
                else:
                    L *= self.eta

            if self.max_steps == 0:
                coefx = coef - G / L
                coefx = penalty.projection(coefx, self.alpha, L)
                coefx /= 1 + self.beta

            t = (1 + np.sqrt(1 + 4 * t_old * t_old)) / 2
            coef = coefx + (t_old - 1) / t * (coefx - coefx_old)
            df = safe_sparse_dot(X, coef.T)

            # Callback might need self.coef_.
            self.coef_ = coef
            if self.callback is not None:
                ret = self.callback(self)
                if ret is not None:
                    break

        return self


class FistaRegressor(MultiOutputMixin, BaseRegressor, _BaseFista):
    """Estimator for learning linear classifiers by FISTA.

    The objective functions considered take the form

    minimize F(W) = C * L(W) + alpha * R(W),

    where L(W) is a loss term and R(W) is a penalty term.

    Parameters
    ----------
    penalty : str or Penalty object, {'l2', 'l1', 'l1/l2', 'simplex'}
        The penalty or constraint to be used.

        - l2: ridge
        - l1: lasso
        - l1/l2: group lasso
        - l1/l2-l1: sparse group lasso
        - tv1d: 1-dimensional total variation (also known as fussed lasso)
        - simplex: simplex constraint
        - SCAD
        - SCADL1
        The method can also take an arbitrary Penalty object, i.e., an instance
        that implements methods projection regularization method (see file penalty.py)


    C : float
        Weight of the loss term.

    alpha : float
        Weight of the penalty term.

    max_iter : int
        Maximum number of iterations to perform.

    max_steps : int
        Maximum number of steps to use during the line search.

    sigma : float
        Constant used in the line search sufficient decrease condition.

    eta : float
         Decrease factor for line-search procedure. For example, eta=2.
         will decrease the step size by a factor of 2 at each iteration
         of the line-search routine.

    callback : callable
        Callback function.

    verbose : int
        Verbosity level.
    """

    def __init__(self, C=1.0, fit_intercept=False, alpha=1.0, alpha_ratio=1.0, beta=0.0, penalty="l1", theta=None, max_iter=100,
                 max_steps=30, eta=2.0, sigma=1e-5, callback=None, verbose=0):
        self.C = C
        self.fit_intercept = fit_intercept
        self.alpha = alpha
        self.alpha_ratio = alpha_ratio
        self.penalty = penalty
        self.beta = beta
        self.max_iter = max_iter
        self.max_steps = max_steps
        self.eta = eta
        self.sigma = sigma
        self.callback = callback
        self.verbose = verbose
        self.theta = theta

    def _get_loss(self):
        return Squared()

    def fit(self, X, y):

        if self.C == '1/n':
            self.C = 1/X.shape[0]

        self.outputs_2d_ = len(y.shape) > 1
        Y = y.reshape(-1, 1) if not self.outputs_2d_ else y
        Y = np.asfortranarray(Y.astype(np.float64))
        n_vectors = Y.shape[1]

        X, y, X_offset, y_offset, X_scale = _preprocess_data(
            X,
            Y,
            fit_intercept=self.fit_intercept,
            normalize=False, # normalizing X should be done externally
            copy=False,
            sample_weight=None,
        )

        self._fit(X, y, n_vectors)

        # SET the incercept after optimization
        self._set_intercept(X_offset, y_offset, X_scale)
        self.coef_ = np.asarray(self.coef_, dtype=X.dtype)

        return self._fit(X, Y, n_vectors)

    def _set_intercept(self, X_offset, y_offset, X_scale):
        """Set the intercept_"""
        if self.fit_intercept:
            self.coef_ = self.coef_ / X_scale # should not change anything since normalize=False
            self.intercept_ = y_offset - np.dot(X_offset, self.coef_.T)
        else:
            self.intercept_ = 0.0
